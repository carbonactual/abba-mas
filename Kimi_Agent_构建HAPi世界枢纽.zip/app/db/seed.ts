import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import * as schema from "./schema";

async function seed() {
  const client = mysql.createPool({
    uri: process.env.DATABASE_URL,
  });
  
  const db = drizzle(client, { schema, mode: "default" });

  // Seed sample posts from various users
  const samplePosts = [
    {
      userId: 1,
      userType: "oauth" as const,
      content: "Just launched my new project on HAPi World Nexus! Excited to connect with everyone here. The community looks amazing! 🚀",
      likesCount: 12,
      commentsCount: 3,
    },
    {
      userId: 2,
      userType: "oauth" as const,
      content: "The future of global connectivity is here. HAPi is redefining how we build communities across borders. What do you think?",
      likesCount: 8,
      commentsCount: 5,
    },
    {
      userId: 1,
      userType: "oauth" as const,
      content: "Working on something special today. Sometimes the best ideas come when you least expect them. Keep creating! ✨",
      likesCount: 15,
      commentsCount: 2,
    },
    {
      userId: 3,
      userType: "oauth" as const,
      content: "Just discovered this incredible platform. The real-time features are next level! Can't wait to explore more.",
      likesCount: 6,
      commentsCount: 1,
    },
    {
      userId: 2,
      userType: "oauth" as const,
      content: "Community is everything. Grateful for all the connections I've made here. Let's keep building together! 🌍",
      likesCount: 20,
      commentsCount: 7,
    },
  ];

  for (const post of samplePosts) {
    try {
      await db.insert(schema.posts).values(post);
    } catch (e) {
      // Skip if fails (e.g., user doesn't exist)
    }
  }

  // Seed sample profiles
  const sampleProfiles = [
    {
      userId: 1,
      userType: "oauth" as const,
      bio: "Building the future of community. Tech enthusiast, dreamer, connector.",
      location: "San Francisco, CA",
      website: "https://example.com",
      interests: "Technology, Design, Community",
      followersCount: 42,
      followingCount: 18,
    },
    {
      userId: 2,
      userType: "oauth" as const,
      bio: "Digital nomad exploring the world one connection at a time.",
      location: "London, UK",
      website: "https://portfolio.example.com",
      interests: "Travel, Photography, AI",
      followersCount: 128,
      followingCount: 56,
    },
  ];

  for (const profile of sampleProfiles) {
    try {
      await db.insert(schema.profiles).values(profile);
    } catch (e) {
      // Skip if fails
    }
  }

  await client.end();
  console.log("Seed data inserted successfully!");
}

seed().catch(console.error);
