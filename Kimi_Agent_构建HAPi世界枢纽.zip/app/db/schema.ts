import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  int,
  boolean,
} from "drizzle-orm/mysql-core";

// ─── Users (OAuth) ─────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Local Users (Username/Password Auth) ──────────────────────
export const localUsers = mysqlTable("local_users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  displayName: varchar("display_name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type LocalUser = typeof localUsers.$inferSelect;
export type InsertLocalUser = typeof localUsers.$inferInsert;

// ─── Profiles ──────────────────────────────────────────────────
export const profiles = mysqlTable("profiles", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  userType: mysqlEnum("user_type", ["oauth", "local"]).default("oauth").notNull(),
  bio: text("bio"),
  location: varchar("location", { length: 255 }),
  website: varchar("website", { length: 255 }),
  banner: text("banner"),
  interests: text("interests"),
  followersCount: int("followers_count").default(0).notNull(),
  followingCount: int("following_count").default(0).notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Profile = typeof profiles.$inferSelect;
export type InsertProfile = typeof profiles.$inferInsert;

// ─── Posts (Feed) ──────────────────────────────────────────────
export const posts = mysqlTable("posts", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  userType: mysqlEnum("user_type", ["oauth", "local"]).default("oauth").notNull(),
  content: text("content").notNull(),
  image: text("image"),
  likesCount: int("likes_count").default(0).notNull(),
  commentsCount: int("comments_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Post = typeof posts.$inferSelect;
export type InsertPost = typeof posts.$inferInsert;

// ─── Connections (Follows) ─────────────────────────────────────
export const connections = mysqlTable("connections", {
  id: serial("id").primaryKey(),
  followerId: bigint("follower_id", { mode: "number", unsigned: true }).notNull(),
  followerType: mysqlEnum("follower_type", ["oauth", "local"]).default("oauth").notNull(),
  followingId: bigint("following_id", { mode: "number", unsigned: true }).notNull(),
  followingType: mysqlEnum("following_type", ["oauth", "local"]).default("oauth").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Connection = typeof connections.$inferSelect;
export type InsertConnection = typeof connections.$inferInsert;

// ─── Messages ──────────────────────────────────────────────────
export const messages = mysqlTable("messages", {
  id: serial("id").primaryKey(),
  senderId: bigint("sender_id", { mode: "number", unsigned: true }).notNull(),
  senderType: mysqlEnum("sender_type", ["oauth", "local"]).default("oauth").notNull(),
  receiverId: bigint("receiver_id", { mode: "number", unsigned: true }).notNull(),
  receiverType: mysqlEnum("receiver_type", ["oauth", "local"]).default("oauth").notNull(),
  content: text("content").notNull(),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

// ─── Notifications ─────────────────────────────────────────────
export const notifications = mysqlTable("notifications", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  userType: mysqlEnum("user_type", ["oauth", "local"]).default("oauth").notNull(),
  type: mysqlEnum("type", ["follow", "like", "comment", "message"]).notNull(),
  actorId: bigint("actor_id", { mode: "number", unsigned: true }).notNull(),
  actorType: mysqlEnum("actor_type", ["oauth", "local"]).default("oauth").notNull(),
  actorName: varchar("actor_name", { length: 255 }),
  actorAvatar: text("actor_avatar"),
  referenceId: bigint("reference_id", { mode: "number", unsigned: true }),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// ─── Post Likes ────────────────────────────────────────────────
export const postLikes = mysqlTable("post_likes", {
  id: serial("id").primaryKey(),
  postId: bigint("post_id", { mode: "number", unsigned: true }).notNull(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  userType: mysqlEnum("user_type", ["oauth", "local"]).default("oauth").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type PostLike = typeof postLikes.$inferSelect;
export type InsertPostLike = typeof postLikes.$inferInsert;
