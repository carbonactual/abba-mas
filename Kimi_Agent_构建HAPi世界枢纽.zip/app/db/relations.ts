import { relations } from "drizzle-orm";
import { users, posts, postLikes } from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  posts: many(posts),
}));

export const postsRelations = relations(posts, ({ many }) => ({
  likes: many(postLikes),
}));
