import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";

import { Skeleton } from "@/components/ui/skeleton";
import {
  Heart,
  MessageCircle,
  Share2,
  Send,
  TrendingUp,
  Users,
  Activity,
  Link as LinkIcon,
} from "lucide-react";
import { useState } from "react";
import { Link } from "react-router";
import { formatDistanceToNow } from "@/lib/utils";

function CreatePost() {
  const { user } = useAuth();
  const [content, setContent] = useState("");
  const utils = trpc.useUtils();

  const createPost = trpc.feed.create.useMutation({
    onSuccess: () => {
      setContent("");
      utils.feed.list.invalidate();
    },
  });

  if (!user) return null;

  return (
    <Card className="mb-6 border-border/60">
      <CardContent className="p-4">
        <div className="flex gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={user.avatar || undefined} />
            <AvatarFallback className="bg-gradient-to-br from-cyan-400 to-blue-500 text-white">
              {(user.name || "U").charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <Textarea
              placeholder="What's happening in your world?"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-[80px] resize-none border-0 bg-transparent focus-visible:ring-0 p-0 text-base placeholder:text-muted-foreground/60"
            />
            <div className="flex items-center justify-between mt-3 pt-3 border-t">
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-500">
                  <LinkIcon className="h-4 w-4" />
                </Button>
              </div>
              <Button
                size="sm"
                disabled={!content.trim() || createPost.isPending}
                onClick={() => createPost.mutate({ content })}
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
              >
                <Send className="h-3.5 w-3.5 mr-1" />
                Post
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function PostCard({ post }: { post: any }) {
  const { isAuthenticated } = useAuth();
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likesCount || 0);

  const likeMutation = trpc.feed.like.useMutation({
    onSuccess: (data) => {
      setLiked(data.liked);
      setLikeCount((prev: number) => data.liked ? prev + 1 : Math.max(0, prev - 1));
    },
  });

  const handleLike = () => {
    if (!isAuthenticated) return;
    likeMutation.mutate({ postId: post.id });
  };

  const authorName = post.user?.name || post.user?.username || "Anonymous";
  const authorAvatar = post.user?.avatar || "";
  const timeAgo = post.createdAt ? formatDistanceToNow(new Date(post.createdAt)) : "";

  return (
    <Card className="mb-4 border-border/60 hover:border-border/80 transition-colors">
      <CardContent className="p-4">
        <div className="flex gap-3">
          <Link to={`/profile/${post.userId}?type=${post.userType}`}>
            <Avatar className="h-10 w-10 cursor-pointer">
              <AvatarImage src={authorAvatar} />
              <AvatarFallback className="bg-gradient-to-br from-cyan-400 to-blue-500 text-white text-sm">
                {authorName.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
          </Link>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <Link
                to={`/profile/${post.userId}?type=${post.userType}`}
                className="font-semibold text-sm hover:underline"
              >
                {authorName}
              </Link>
              <span className="text-xs text-muted-foreground">{timeAgo}</span>
            </div>
            <p className="text-sm leading-relaxed whitespace-pre-wrap mb-3">{post.content}</p>
            {post.image && (
              <img
                src={post.image}
                alt="Post attachment"
                className="rounded-lg max-h-80 object-cover mb-3 w-full"
              />
            )}
            <div className="flex items-center gap-4">
              <button
                onClick={handleLike}
                className={`flex items-center gap-1.5 text-xs transition-colors ${
                  liked
                    ? "text-red-500"
                    : "text-muted-foreground hover:text-red-500"
                }`}
              >
                <Heart className={`h-4 w-4 ${liked ? "fill-current" : ""}`} />
                <span>{likeCount}</span>
              </button>
              <button className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-blue-500 transition-colors">
                <MessageCircle className="h-4 w-4" />
                <span>{post.commentsCount || 0}</span>
              </button>
              <button className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-green-500 transition-colors">
                <Share2 className="h-4 w-4" />
                <span>Share</span>
              </button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function FeedSkeleton() {
  return (
    <div className="space-y-4">
      {[1, 2, 3].map((i) => (
        <Card key={i} className="border-border/60">
          <CardContent className="p-4">
            <div className="flex gap-3">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-3 w-full" />
                <Skeleton className="h-3 w-3/4" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function StatsCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: string; color: string }) {
  return (
    <Card className="border-border/60">
      <CardContent className="p-4 flex items-center gap-3">
        <div className={`p-2.5 rounded-lg ${color}`}>
          <Icon className="h-5 w-5 text-white" />
        </div>
        <div>
          <p className="text-2xl font-bold">{value}</p>
          <p className="text-xs text-muted-foreground">{label}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Home() {
  const { isAuthenticated } = useAuth();
  const { data: posts, isLoading } = trpc.feed.list.useQuery({ limit: 50, offset: 0 });
  const { data: allPosts } = trpc.feed.list.useQuery({ limit: 1000, offset: 0 });

  const totalPosts = allPosts?.length || 0;
  const totalLikes = allPosts?.reduce((sum: number, p: any) => sum + (p.likesCount || 0), 0) || 0;

  return (
    <div className="space-y-6">
      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-2xl p-6 lg:p-8">
        <div className="absolute inset-0">
          <img src="/hero-bg.jpg" alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 via-blue-950/80 to-slate-900/90" />
        </div>
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-10 left-10 w-32 h-32 bg-cyan-400 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-40 h-40 bg-blue-500 rounded-full blur-3xl" />
        </div>
        <div className="relative z-10">
          <h1 className="text-2xl lg:text-3xl font-bold text-white mb-2">
            Welcome to HAPi World Nexus
          </h1>
          <p className="text-blue-200 text-sm lg:text-base max-w-lg">
            Connect, share, and discover with the global community. Your world, united.
          </p>
          <div className="flex gap-3 mt-4">
            <StatsCard
              icon={Activity}
              label="Total Posts"
              value={totalPosts.toString()}
              color="bg-gradient-to-br from-cyan-400 to-cyan-600"
            />
            <StatsCard
              icon={Heart}
              label="Total Likes"
              value={totalLikes.toString()}
              color="bg-gradient-to-br from-pink-400 to-red-500"
            />
          </div>
        </div>
      </div>

      {/* Create Post */}
      {isAuthenticated && <CreatePost />}

      {/* Feed */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-blue-500" />
            Live Feed
          </h2>
        </div>

        {isLoading ? (
          <FeedSkeleton />
        ) : posts && posts.length > 0 ? (
          <div>
            {posts.map((post: any) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        ) : (
          <Card className="border-border/60">
            <CardContent className="p-8 text-center">
              <Users className="h-12 w-12 mx-auto text-muted-foreground/40 mb-3" />
              <p className="text-muted-foreground font-medium">No posts yet</p>
              <p className="text-sm text-muted-foreground/60 mt-1">
                Be the first to share something with the community!
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
