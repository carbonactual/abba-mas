import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, MessageSquare, ArrowLeft } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { useSearchParams } from "react-router";
import { formatDistanceToNow } from "@/lib/utils";

export default function Messages() {
  const { user, isAuthenticated } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const [messageInput, setMessageInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const selectedUserId = searchParams.get("id") ? parseInt(searchParams.get("id")!) : null;
  const selectedUserType = (searchParams.get("type") || "oauth") as "oauth" | "local";

  const utils = trpc.useUtils();

  const { data: conversations, isLoading: convLoading } = trpc.message.conversations.useQuery(
    undefined,
    { enabled: isAuthenticated, refetchInterval: 10000 }
  );

  const { data: messages, isLoading: msgLoading } = trpc.message.list.useQuery(
    { otherUserId: selectedUserId || 0, otherUserType: selectedUserType },
    { enabled: !!selectedUserId && isAuthenticated, refetchInterval: 5000 }
  );

  const sendMessage = trpc.message.send.useMutation({
    onSuccess: () => {
      setMessageInput("");
      utils.message.list.invalidate();
      utils.message.conversations.invalidate();
    },
  });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  if (!isAuthenticated) {
    return (
      <Card className="border-border/60">
        <CardContent className="p-8 text-center">
          <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-muted-foreground font-medium">Sign in to send messages</p>
        </CardContent>
      </Card>
    );
  }

  const currentUserId = user?.id || 0;
  const currentUserType = user?.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;

  // Get unique conversations from messages
  const conversationList = conversations || [];

  const handleSend = () => {
    if (!messageInput.trim() || !selectedUserId) return;
    sendMessage.mutate({
      receiverId: selectedUserId,
      receiverType: selectedUserType,
      content: messageInput.trim(),
    });
  };

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold flex items-center gap-2">
        <MessageSquare className="h-5 w-5 text-blue-500" />
        Messages
      </h1>

      <div className="grid lg:grid-cols-3 gap-4 h-[calc(100vh-180px)]">
        {/* Conversation List */}
        <Card className="lg:col-span-1 border-border/60 overflow-hidden">
          <CardContent className="p-0">
            <div className="p-3 border-b font-semibold text-sm">Conversations</div>
            <ScrollArea className="h-[calc(100%-45px)]">
              {convLoading ? (
                <div className="p-3 space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex gap-3">
                      <Skeleton className="h-10 w-10 rounded-full" />
                      <div className="flex-1 space-y-1">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-3 w-full" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : conversationList.length > 0 ? (
                <div>
                  {conversationList.map((msg: any, idx: number) => {
                    const isSent = msg.senderId === currentUserId && msg.senderType === currentUserType;
                    const otherId = isSent ? msg.receiverId : msg.senderId;
                    const otherType = isSent ? msg.receiverType : msg.senderType;
                    const isSelected = selectedUserId === otherId && selectedUserType === otherType;

                    return (
                      <button
                        key={idx}
                        onClick={() => setSearchParams({ id: `${otherId}`, type: otherType })}
                        className={`w-full flex items-start gap-3 p-3 text-left transition-colors hover:bg-accent ${
                          isSelected ? "bg-gradient-to-r from-cyan-50 to-blue-50 dark:from-cyan-950/20 dark:to-blue-950/20" : ""
                        }`}
                      >
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="bg-gradient-to-br from-cyan-400 to-blue-500 text-white text-sm">
                            U
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium truncate">User {otherId}</span>
                            <span className="text-xs text-muted-foreground">
                              {msg.createdAt ? formatDistanceToNow(new Date(msg.createdAt)) : ""}
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground truncate mt-0.5">
                            {isSent ? "You: " : ""}{msg.content}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <p className="text-sm text-muted-foreground">No conversations yet</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Start messaging from a user&apos;s profile
                  </p>
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Chat Area */}
        <Card className="lg:col-span-2 border-border/60 flex flex-col overflow-hidden">
          {selectedUserId ? (
            <>
              {/* Chat Header */}
              <div className="p-3 border-b flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="icon"
                  className="lg:hidden h-8 w-8"
                  onClick={() => setSearchParams({})}
                >
                  <ArrowLeft className="h-4 w-4" />
                </Button>
                <Avatar className="h-9 w-9">
                  <AvatarFallback className="bg-gradient-to-br from-cyan-400 to-blue-500 text-white text-sm">
                    U
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-semibold">User {selectedUserId}</p>
                  <p className="text-xs text-muted-foreground">{selectedUserType}</p>
                </div>
              </div>

              {/* Messages */}
              <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
                {msgLoading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className={`flex ${i % 2 === 0 ? "justify-end" : "justify-start"}`}>
                        <Skeleton className={`h-12 ${i % 2 === 0 ? "w-48" : "w-56"} rounded-xl`} />
                      </div>
                    ))}
                  </div>
                ) : messages && messages.length > 0 ? (
                  messages.map((msg: any) => {
                    const isMe = msg.senderId === currentUserId && msg.senderType === currentUserType;
                    return (
                      <div
                        key={msg.id}
                        className={`flex ${isMe ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-[70%] px-4 py-2.5 rounded-2xl text-sm ${
                            isMe
                              ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-br-md"
                              : "bg-muted rounded-bl-md"
                          }`}
                        >
                          <p>{msg.content}</p>
                          <p
                            className={`text-xs mt-1 ${
                              isMe ? "text-blue-100" : "text-muted-foreground"
                            }`}
                          >
                            {msg.createdAt ? formatDistanceToNow(new Date(msg.createdAt)) : ""}
                          </p>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="h-full flex items-center justify-center">
                    <p className="text-muted-foreground text-sm">No messages yet. Say hello!</p>
                  </div>
                )}
              </div>

              {/* Input */}
              <div className="p-3 border-t flex gap-2">
                <Input
                  placeholder="Type a message..."
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSend()}
                  className="flex-1"
                />
                <Button
                  onClick={handleSend}
                  disabled={!messageInput.trim() || sendMessage.isPending}
                  className="bg-gradient-to-r from-cyan-500 to-blue-600"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </>
          ) : (
            <div className="h-full flex flex-col items-center justify-center p-8">
              <MessageSquare className="h-16 w-16 text-muted-foreground/30 mb-4" />
              <p className="text-muted-foreground font-medium">Select a conversation</p>
              <p className="text-sm text-muted-foreground/60 text-center mt-1">
                Choose a conversation from the list to start messaging
              </p>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
