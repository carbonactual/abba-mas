import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  MapPin,
  Link as LinkIcon,
  Heart,
  Calendar,
  Edit3,
  MessageCircle,
  UserPlus,
  UserCheck,
} from "lucide-react";
import { useState } from "react";
import { Link, useSearchParams } from "react-router";
import { formatDistanceToNow } from "@/lib/utils";

function EditProfileDialog({ profile, onUpdate }: { profile: any; onUpdate: () => void }) {
  const [bio, setBio] = useState(profile?.bio || "");
  const [location, setLocation] = useState(profile?.location || "");
  const [website, setWebsite] = useState(profile?.website || "");
  const [interests, setInterests] = useState(profile?.interests || "");
  const [open, setOpen] = useState(false);

  const updateProfile = trpc.profile.update.useMutation({
    onSuccess: () => {
      onUpdate();
      setOpen(false);
    },
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1.5">
          <Edit3 className="h-3.5 w-3.5" />
          Edit Profile
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edit Profile</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-4">
          <div>
            <Label htmlFor="bio">Bio</Label>
            <Textarea
              id="bio"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell us about yourself"
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="location">Location</Label>
            <div className="relative mt-1">
              <MapPin className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Your location"
                className="pl-9"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="website">Website</Label>
            <div className="relative mt-1">
              <LinkIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                id="website"
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                placeholder="Your website"
                className="pl-9"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="interests">Interests</Label>
            <Textarea
              id="interests"
              value={interests}
              onChange={(e) => setInterests(e.target.value)}
              placeholder="What are you interested in?"
              className="mt-1"
            />
          </div>
          <Button
            onClick={() => updateProfile.mutate({ bio, location, website, interests })}
            disabled={updateProfile.isPending}
            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
          >
            {updateProfile.isPending ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function Profile() {
  const { user, isAuthenticated } = useAuth();
  const [searchParams] = useSearchParams();
  const profileUserId = searchParams.get("id") ? parseInt(searchParams.get("id")!) : user?.id;
  const profileUserType = (searchParams.get("type") || "oauth") as "oauth" | "local";
  const isOwnProfile = !searchParams.get("id") || (profileUserId === user?.id);

  const utils = trpc.useUtils();

  const { data: profileData, isLoading } = trpc.profile.get.useQuery(
    { userId: profileUserId || 0, userType: profileUserType },
    { enabled: !!profileUserId }
  );

  const { data: userPosts } = trpc.feed.listByUser.useQuery(
    { userId: profileUserId || 0, userType: profileUserType, limit: 50 },
    { enabled: !!profileUserId }
  );

  const { data: followers } = trpc.connection.followers.useQuery(
    { userId: profileUserId || 0, userType: profileUserType },
    { enabled: !!profileUserId }
  );

  const { data: following } = trpc.connection.following.useQuery(
    { userId: profileUserId || 0, userType: profileUserType },
    { enabled: !!profileUserId }
  );

  const { data: isFollowingUser } = trpc.connection.check.useQuery(
    {
      followerId: user?.id || 0,
      followerType: user?.unionId?.startsWith("local_") ? "local" : "oauth",
      followingId: profileUserId || 0,
      followingType: profileUserType,
    },
    { enabled: !!user && !isOwnProfile && !!profileUserId }
  );

  const followMutation = trpc.connection.follow.useMutation({
    onSuccess: () => {
      utils.connection.check.invalidate();
      utils.connection.followers.invalidate();
    },
  });

  const unfollowMutation = trpc.connection.unfollow.useMutation({
    onSuccess: () => {
      utils.connection.check.invalidate();
      utils.connection.followers.invalidate();
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-48 w-full rounded-xl" />
        <div className="flex gap-4">
          <Skeleton className="h-20 w-20 rounded-full" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-5 w-48" />
            <Skeleton className="h-4 w-32" />
          </div>
        </div>
      </div>
    );
  }

  const profileUser = profileData?.user;
  const profile = profileData?.profile;
  const displayName = profileUser?.name || profileUser?.username || "Anonymous";
  const avatar = profileUser?.avatar || "";
  const bio = profile?.bio || "No bio yet.";

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="relative h-48 rounded-xl overflow-hidden bg-gradient-to-br from-slate-800 via-blue-900 to-slate-800">
        {profile?.banner && (
          <img src={profile.banner} alt="Banner" className="w-full h-full object-cover" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
      </div>

      {/* Profile Info */}
      <div className="relative px-4 -mt-16">
        <div className="flex flex-col sm:flex-row items-start sm:items-end gap-4">
          <Avatar className="h-24 w-24 border-4 border-background shadow-lg">
            <AvatarImage src={avatar} />
            <AvatarFallback className="bg-gradient-to-br from-cyan-400 to-blue-500 text-white text-2xl">
              {displayName.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0 pb-1">
            <h1 className="text-2xl font-bold">{displayName}</h1>
            <p className="text-muted-foreground text-sm">
              {profileUser?.username ? `@${profileUser.username}` : profileUser?.email || ""}
            </p>
          </div>
          <div className="flex gap-2">
            {isOwnProfile && isAuthenticated ? (
              <EditProfileDialog profile={profile} onUpdate={() => utils.profile.get.invalidate()} />
            ) : isAuthenticated ? (
              <>
                <Button
                  variant={isFollowingUser ? "default" : "outline"}
                  size="sm"
                  onClick={() =>
                    isFollowingUser
                      ? unfollowMutation.mutate({ followingId: profileUserId || 0, followingType: profileUserType })
                      : followMutation.mutate({ followingId: profileUserId || 0, followingType: profileUserType })
                  }
                  disabled={followMutation.isPending || unfollowMutation.isPending}
                  className={isFollowingUser ? "bg-gradient-to-r from-cyan-500 to-blue-600" : ""}
                >
                  {isFollowingUser ? (
                    <><UserCheck className="h-3.5 w-3.5 mr-1" /> Following</>
                  ) : (
                    <><UserPlus className="h-3.5 w-3.5 mr-1" /> Follow</>
                  )}
                </Button>
                <Link to={`/messages?id=${profileUserId}&type=${profileUserType}`}>
                  <Button variant="outline" size="sm">
                    <MessageCircle className="h-3.5 w-3.5 mr-1" />
                    Message
                  </Button>
                </Link>
              </>
            ) : null}
          </div>
        </div>

        {/* Bio & Details */}
        <div className="mt-4 space-y-3">
          <p className="text-sm leading-relaxed">{bio}</p>
          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
            {profile?.location && (
              <span className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                {profile.location}
              </span>
            )}
            {profile?.website && (
              <a
                href={profile.website}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 hover:text-blue-500 transition-colors"
              >
                <LinkIcon className="h-4 w-4" />
                {profile.website.replace(/^https?:\/\//, "")}
              </a>
            )}
            {profileUser?.createdAt && (
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                Joined {new Date(profileUser.createdAt).toLocaleDateString("en-US", { month: "long", year: "numeric" })}
              </span>
            )}
          </div>
          {profile?.interests && (
            <div className="flex flex-wrap gap-2">
              {profile.interests.split(",").map((interest: string) => (
                <span
                  key={interest.trim()}
                  className="px-2.5 py-1 rounded-full text-xs bg-gradient-to-r from-cyan-50 to-blue-50 text-blue-700 dark:from-cyan-950/30 dark:to-blue-950/30 dark:text-blue-400 border border-blue-100 dark:border-blue-900"
                >
                  {interest.trim()}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="flex gap-6 mt-4">
          <div className="text-center">
            <p className="text-lg font-bold">{userPosts?.length || 0}</p>
            <p className="text-xs text-muted-foreground">Posts</p>
          </div>
          <div className="text-center">
            <p className="text-lg font-bold">{followers?.length || 0}</p>
            <p className="text-xs text-muted-foreground">Followers</p>
          </div>
          <div className="text-center">
            <p className="text-lg font-bold">{following?.length || 0}</p>
            <p className="text-xs text-muted-foreground">Following</p>
          </div>
        </div>
      </div>

      <Separator />

      {/* Posts */}
      <div>
        <h2 className="text-lg font-semibold mb-4">Posts</h2>
        {userPosts && userPosts.length > 0 ? (
          <div className="space-y-4">
            {userPosts.map((post: any) => (
              <Card key={post.id} className="border-border/60">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs text-muted-foreground">
                      {post.createdAt ? formatDistanceToNow(new Date(post.createdAt)) : ""}
                    </span>
                  </div>
                  <p className="text-sm leading-relaxed">{post.content}</p>
                  <div className="flex gap-4 mt-3">
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Heart className="h-3.5 w-3.5" /> {post.likesCount || 0}
                    </span>
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <MessageCircle className="h-3.5 w-3.5" /> {post.commentsCount || 0}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-border/60">
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground">No posts yet</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
