import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Bell,
  UserPlus,
  Heart,
  MessageCircle,
  Check,
  Inbox,
} from "lucide-react";
import { useEffect } from "react";
import { formatDistanceToNow } from "@/lib/utils";

const typeIcons = {
  follow: UserPlus,
  like: Heart,
  comment: MessageCircle,
  message: MessageCircle,
};

const typeColors = {
  follow: "text-blue-500 bg-blue-50 dark:bg-blue-950/30",
  like: "text-red-500 bg-red-50 dark:bg-red-950/30",
  comment: "text-green-500 bg-green-50 dark:bg-green-950/30",
  message: "text-purple-500 bg-purple-50 dark:bg-purple-950/30",
};

export default function Notifications() {
  const { isAuthenticated } = useAuth();
  const utils = trpc.useUtils();

  const { data: notifications, isLoading } = trpc.notification.list.useQuery(
    { limit: 50 },
    { enabled: isAuthenticated, refetchInterval: 15000 }
  );

  const markRead = trpc.notification.markRead.useMutation({
    onSuccess: () => {
      utils.notification.list.invalidate();
      utils.notification.unreadCount.invalidate();
    },
  });

  useEffect(() => {
    if (notifications && notifications.some((n: any) => !n.read)) {
      const timer = setTimeout(() => markRead.mutate(), 2000);
      return () => clearTimeout(timer);
    }
  }, [notifications]);

  if (!isAuthenticated) {
    return (
      <Card className="border-border/60">
        <CardContent className="p-8 text-center">
          <Bell className="h-12 w-12 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-muted-foreground font-medium">Sign in to view notifications</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <Bell className="h-5 w-5 text-blue-500" />
          Notifications
        </h1>
        {notifications?.some((n: any) => !n.read) && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => markRead.mutate()}
            disabled={markRead.isPending}
          >
            <Check className="h-3.5 w-3.5 mr-1" />
            Mark all read
          </Button>
        )}
      </div>

      <Card className="border-border/60">
        <CardContent className="p-0">
          <ScrollArea className="max-h-[calc(100vh-200px)]">
            {isLoading ? (
              <div className="p-4 space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex gap-3">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="flex-1 space-y-1">
                      <Skeleton className="h-4 w-48" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                  </div>
                ))}
              </div>
            ) : notifications && notifications.length > 0 ? (
              <div>
                {notifications.map((notif: any) => {
                  const Icon = typeIcons[notif.type as keyof typeof typeIcons] || Bell;
                  const colorClass = typeColors[notif.type as keyof typeof typeColors] || "";

                  return (
                    <div
                      key={notif.id}
                      className={`flex items-start gap-3 p-4 border-b last:border-b-0 transition-colors hover:bg-accent/50 ${
                        !notif.read ? "bg-blue-50/50 dark:bg-blue-950/10" : ""
                      }`}
                    >
                      <div className={`p-2 rounded-full ${colorClass}`}>
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={notif.actorAvatar || undefined} />
                            <AvatarFallback className="bg-gradient-to-br from-cyan-400 to-blue-500 text-white text-xs">
                              {(notif.actorName || "U").charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <p className="text-sm">
                            <span className="font-semibold">{notif.actorName || "Someone"}</span>{" "}
                            {notif.type === "follow" && "started following you"}
                            {notif.type === "like" && "liked your post"}
                            {notif.type === "comment" && "commented on your post"}
                            {notif.type === "message" && "sent you a message"}
                          </p>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1 ml-10">
                          {notif.createdAt ? formatDistanceToNow(new Date(notif.createdAt)) : ""}
                        </p>
                      </div>
                      {!notif.read && (
                        <div className="h-2.5 w-2.5 rounded-full bg-blue-500 mt-2 shrink-0" />
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-8 text-center">
                <Inbox className="h-12 w-12 mx-auto text-muted-foreground/40 mb-3" />
                <p className="text-muted-foreground font-medium">No notifications yet</p>
                <p className="text-sm text-muted-foreground/60 mt-1">
                  When someone interacts with you, it will show up here
                </p>
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
