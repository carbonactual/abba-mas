import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, UserPlus, UserCheck, MapPin, TrendingUp, Sparkles } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router";

type UserItem = {
  id: number;
  name: string | null;
  username?: string;
  email: string | null;
  avatar: string | null;
  role: string;
  createdAt: Date;
  type: "oauth" | "local";
  bio?: string | null;
  location?: string | null;
  followersCount?: number;
  followingCount?: number;
};

function UserCard({ user: userItem }: { user: UserItem }) {
  const { user: currentUser, isAuthenticated } = useAuth();
  const utils = trpc.useUtils();
  const isMe = currentUser?.id === userItem.id && 
    (currentUser?.unionId?.startsWith("local_") ? "local" : "oauth") === userItem.type;

  const { data: isFollowing } = trpc.connection.check.useQuery(
    {
      followerId: currentUser?.id || 0,
      followerType: currentUser?.unionId?.startsWith("local_") ? "local" : "oauth",
      followingId: userItem.id,
      followingType: userItem.type,
    },
    { enabled: isAuthenticated && !isMe }
  );

  const followMutation = trpc.connection.follow.useMutation({
    onSuccess: () => utils.connection.check.invalidate(),
  });

  const unfollowMutation = trpc.connection.unfollow.useMutation({
    onSuccess: () => utils.connection.check.invalidate(),
  });

  const displayName = userItem.name || userItem.username || "Anonymous";
  const userLink = `/profile?id=${userItem.id}&type=${userItem.type}`;

  return (
    <Card className="border-border/60 hover:border-blue-300/50 transition-all group">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <Link to={userLink}>
            <Avatar className="h-12 w-12 cursor-pointer">
              <AvatarImage src={userItem.avatar || undefined} />
              <AvatarFallback className="bg-gradient-to-br from-cyan-400 to-blue-500 text-white">
                {displayName.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
          </Link>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <Link to={userLink} className="font-semibold text-sm hover:underline truncate block">
                  {displayName}
                </Link>
                <p className="text-xs text-muted-foreground truncate">
                  {userItem.username ? `@${userItem.username}` : userItem.email || ""}
                </p>
              </div>
              {!isMe && isAuthenticated && (
                <Button
                  variant={isFollowing ? "default" : "outline"}
                  size="sm"
                  className={`h-8 text-xs ${isFollowing ? "bg-gradient-to-r from-cyan-500 to-blue-600" : ""}`}
                  onClick={() =>
                    isFollowing
                      ? unfollowMutation.mutate({ followingId: userItem.id, followingType: userItem.type })
                      : followMutation.mutate({ followingId: userItem.id, followingType: userItem.type })
                  }
                  disabled={followMutation.isPending || unfollowMutation.isPending}
                >
                  {isFollowing ? (
                    <><UserCheck className="h-3.5 w-3.5 mr-1" /> Following</>
                  ) : (
                    <><UserPlus className="h-3.5 w-3.5 mr-1" /> Follow</>
                  )}
                </Button>
              )}
            </div>
            {userItem.bio && (
              <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{userItem.bio}</p>
            )}
            <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
              {userItem.location && (
                <span className="flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  {userItem.location}
                </span>
              )}
              <span>{userItem.followersCount || 0} followers</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Discover() {
  const [searchQuery, setSearchQuery] = useState("");
  const { data: feedPosts } = trpc.feed.list.useQuery({ limit: 5, offset: 0 });

  const allUsers: UserItem[] = [];

  // Get OAuth users from feed posts (unique authors)
  const oauthUserIds = new Set<number>();
  if (feedPosts) {
    for (const post of feedPosts) {
      if (post.user && !oauthUserIds.has(post.user.id)) {
        oauthUserIds.add(post.user.id);
        const userName = "name" in post.user ? post.user.name : (post.user.displayName || post.user.username);
        const userUsername = "username" in post.user ? post.user.username : undefined;
        allUsers.push({
          id: post.user.id,
          name: userName,
          username: userUsername,
          email: post.user.email,
          avatar: post.user.avatar,
          role: post.user.role,
          createdAt: post.user.createdAt,
          type: post.userType,
          bio: post.profile?.bio,
          location: post.profile?.location,
          followersCount: post.profile?.followersCount,
          followingCount: post.profile?.followingCount,
        });
      }
    }
  }

  const filteredUsers = searchQuery
    ? allUsers.filter(
        (u) =>
          (u.name?.toLowerCase() || "").includes(searchQuery.toLowerCase()) ||
          (u.username?.toLowerCase() || "").includes(searchQuery.toLowerCase()) ||
          (u.email?.toLowerCase() || "").includes(searchQuery.toLowerCase()) ||
          (u.bio?.toLowerCase() || "").includes(searchQuery.toLowerCase())
      )
    : allUsers;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 p-6">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-5 right-20 w-24 h-24 bg-cyan-400 rounded-full blur-3xl" />
          <div className="absolute bottom-5 left-20 w-32 h-32 bg-purple-500 rounded-full blur-3xl" />
        </div>
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="h-5 w-5 text-yellow-400" />
            <h1 className="text-xl font-bold text-white">Discover People</h1>
          </div>
          <p className="text-indigo-200 text-sm">
            Find and connect with amazing people in the HAPi community.
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name, username, or interests..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="border-border/60">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-gradient-to-br from-blue-400 to-blue-600">
              <TrendingUp className="h-4 w-4 text-white" />
            </div>
            <div>
              <p className="text-lg font-bold">{allUsers.length}</p>
              <p className="text-xs text-muted-foreground">Community Members</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-gradient-to-br from-green-400 to-green-600">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <div>
              <p className="text-lg font-bold">{feedPosts?.length || 0}</p>
              <p className="text-xs text-muted-foreground">Recent Posts</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* User Grid */}
      <div>
        <h2 className="text-lg font-semibold mb-4">
          {searchQuery ? `Search Results (${filteredUsers.length})` : "Community Members"}
        </h2>
        {filteredUsers.length > 0 ? (
          <div className="grid gap-3">
            {filteredUsers.map((userItem) => (
              <UserCard key={`${userItem.type}-${userItem.id}`} user={userItem} />
            ))}
          </div>
        ) : (
          <Card className="border-border/60">
            <CardContent className="p-8 text-center">
              <Search className="h-12 w-12 mx-auto text-muted-foreground/40 mb-3" />
              <p className="text-muted-foreground">
                {searchQuery ? "No users found matching your search" : "No users to discover yet"}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
