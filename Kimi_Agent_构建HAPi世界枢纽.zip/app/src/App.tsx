import { Routes, Route } from 'react-router'
import AppLayout from './components/AppLayout'
import Home from './pages/Home'
import Profile from './pages/Profile'
import Discover from './pages/Discover'
import Messages from './pages/Messages'
import Notifications from './pages/Notifications'
import Login from './pages/Login'
import NotFound from './pages/NotFound'

function LayoutWrapper({ children }: { children: React.ReactNode }) {
  return <AppLayout>{children}</AppLayout>
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/"
        element={
          <LayoutWrapper>
            <Home />
          </LayoutWrapper>
        }
      />
      <Route
        path="/profile"
        element={
          <LayoutWrapper>
            <Profile />
          </LayoutWrapper>
        }
      />
      <Route
        path="/discover"
        element={
          <LayoutWrapper>
            <Discover />
          </LayoutWrapper>
        }
      />
      <Route
        path="/messages"
        element={
          <LayoutWrapper>
            <Messages />
          </LayoutWrapper>
        }
      />
      <Route
        path="/notifications"
        element={
          <LayoutWrapper>
            <Notifications />
          </LayoutWrapper>
        }
      />
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
