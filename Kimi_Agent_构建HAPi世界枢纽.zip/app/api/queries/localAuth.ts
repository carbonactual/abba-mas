import { eq } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./connection";
import { hashSync, compareSync } from "bcrypt-ts";

export async function findLocalUserByUsername(username: string) {
  const rows = await getDb()
    .select()
    .from(schema.localUsers)
    .where(eq(schema.localUsers.username, username))
    .limit(1);
  return rows.at(0);
}

export async function findLocalUserById(id: number) {
  const rows = await getDb()
    .select()
    .from(schema.localUsers)
    .where(eq(schema.localUsers.id, id))
    .limit(1);
  return rows.at(0);
}

export async function createLocalUser(username: string, password: string, displayName?: string, email?: string) {
  const passwordHash = hashSync(password, 10);
  const result = await getDb()
    .insert(schema.localUsers)
    .values({
      username,
      displayName: displayName || username,
      email,
      passwordHash,
    });
  return result;
}

export async function validateLocalUser(username: string, password: string) {
  const user = await findLocalUserByUsername(username);
  if (!user) return null;
  const valid = compareSync(password, user.passwordHash);
  if (!valid) return null;
  return user;
}
