import { eq, and, or, desc, asc } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./connection";

export async function createMessage(data: schema.InsertMessage) {
  const result = await getDb().insert(schema.messages).values(data);
  return result;
}

export async function listMessagesBetweenUsers(
  user1Id: number, user1Type: "oauth" | "local",
  user2Id: number, user2Type: "oauth" | "local",
  limit = 100
) {
  return getDb()
    .select()
    .from(schema.messages)
    .where(or(
      and(
        eq(schema.messages.senderId, user1Id),
        eq(schema.messages.senderType, user1Type),
        eq(schema.messages.receiverId, user2Id),
        eq(schema.messages.receiverType, user2Type)
      ),
      and(
        eq(schema.messages.senderId, user2Id),
        eq(schema.messages.senderType, user2Type),
        eq(schema.messages.receiverId, user1Id),
        eq(schema.messages.receiverType, user1Type)
      )
    ))
    .orderBy(asc(schema.messages.createdAt))
    .limit(limit);
}

export async function listConversations(userId: number, userType: "oauth" | "local" = "oauth") {
  const sent = await getDb()
    .select()
    .from(schema.messages)
    .where(and(
      eq(schema.messages.senderId, userId),
      eq(schema.messages.senderType, userType)
    ))
    .orderBy(desc(schema.messages.createdAt));

  const received = await getDb()
    .select()
    .from(schema.messages)
    .where(and(
      eq(schema.messages.receiverId, userId),
      eq(schema.messages.receiverType, userType)
    ))
    .orderBy(desc(schema.messages.createdAt));

  const allMessages = [...sent, ...received];
  const conversationMap = new Map<string, typeof allMessages[0]>();

  for (const msg of allMessages) {
    const otherId = msg.senderId === userId && msg.senderType === userType
      ? `${msg.receiverId}-${msg.receiverType}`
      : `${msg.senderId}-${msg.senderType}`;
    if (!conversationMap.has(otherId)) {
      conversationMap.set(otherId, msg);
    }
  }

  return Array.from(conversationMap.values());
}

export async function markMessagesAsRead(
  senderId: number, senderType: "oauth" | "local",
  receiverId: number, receiverType: "oauth" | "local"
) {
  await getDb()
    .update(schema.messages)
    .set({ read: true })
    .where(and(
      eq(schema.messages.senderId, senderId),
      eq(schema.messages.senderType, senderType),
      eq(schema.messages.receiverId, receiverId),
      eq(schema.messages.receiverType, receiverType),
      eq(schema.messages.read, false)
    ));
}

export async function getUnreadCount(userId: number, userType: "oauth" | "local" = "oauth") {
  const rows = await getDb()
    .select()
    .from(schema.messages)
    .where(and(
      eq(schema.messages.receiverId, userId),
      eq(schema.messages.receiverType, userType),
      eq(schema.messages.read, false)
    ));
  return rows.length;
}
