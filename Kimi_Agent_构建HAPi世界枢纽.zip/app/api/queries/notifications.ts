import { eq, and, desc } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./connection";

export async function createNotification(data: schema.InsertNotification) {
  const result = await getDb().insert(schema.notifications).values(data);
  return result;
}

export async function listNotifications(userId: number, userType: "oauth" | "local" = "oauth", limit = 50) {
  return getDb()
    .select()
    .from(schema.notifications)
    .where(and(
      eq(schema.notifications.userId, userId),
      eq(schema.notifications.userType, userType)
    ))
    .orderBy(desc(schema.notifications.createdAt))
    .limit(limit);
}

export async function markNotificationsAsRead(userId: number, userType: "oauth" | "local" = "oauth") {
  await getDb()
    .update(schema.notifications)
    .set({ read: true })
    .where(and(
      eq(schema.notifications.userId, userId),
      eq(schema.notifications.userType, userType),
      eq(schema.notifications.read, false)
    ));
}

export async function getUnreadNotificationCount(userId: number, userType: "oauth" | "local" = "oauth") {
  const rows = await getDb()
    .select()
    .from(schema.notifications)
    .where(and(
      eq(schema.notifications.userId, userId),
      eq(schema.notifications.userType, userType),
      eq(schema.notifications.read, false)
    ));
  return rows.length;
}
