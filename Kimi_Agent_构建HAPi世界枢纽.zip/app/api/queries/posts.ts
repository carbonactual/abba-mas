import { eq, desc, and, sql } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./connection";

export async function createPost(data: schema.InsertPost) {
  const result = await getDb().insert(schema.posts).values(data);
  return result;
}

export async function findPostById(id: number) {
  const rows = await getDb()
    .select()
    .from(schema.posts)
    .where(eq(schema.posts.id, id))
    .limit(1);
  return rows.at(0);
}

export async function listPosts(limit = 50, offset = 0) {
  return getDb()
    .select()
    .from(schema.posts)
    .orderBy(desc(schema.posts.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function listPostsByUser(userId: number, userType: "oauth" | "local" = "oauth", limit = 50) {
  return getDb()
    .select()
    .from(schema.posts)
    .where(and(
      eq(schema.posts.userId, userId),
      eq(schema.posts.userType, userType)
    ))
    .orderBy(desc(schema.posts.createdAt))
    .limit(limit);
}

export async function deletePost(id: number) {
  await getDb()
    .delete(schema.posts)
    .where(eq(schema.posts.id, id));
}

export async function incrementPostLikes(postId: number) {
  await getDb()
    .update(schema.posts)
    .set({ likesCount: sql`${schema.posts.likesCount} + 1` })
    .where(eq(schema.posts.id, postId));
}

export async function decrementPostLikes(postId: number) {
  await getDb()
    .update(schema.posts)
    .set({ likesCount: sql`${schema.posts.likesCount} - 1` })
    .where(eq(schema.posts.id, postId));
}

export async function userLikedPost(postId: number, userId: number, userType: "oauth" | "local" = "oauth") {
  const rows = await getDb()
    .select()
    .from(schema.postLikes)
    .where(and(
      eq(schema.postLikes.postId, postId),
      eq(schema.postLikes.userId, userId),
      eq(schema.postLikes.userType, userType)
    ))
    .limit(1);
  return rows.length > 0;
}

export async function likePost(postId: number, userId: number, userType: "oauth" | "local" = "oauth") {
  await getDb().insert(schema.postLikes).values({ postId, userId, userType });
  await incrementPostLikes(postId);
}

export async function unlikePost(postId: number, userId: number, userType: "oauth" | "local" = "oauth") {
  await getDb()
    .delete(schema.postLikes)
    .where(and(
      eq(schema.postLikes.postId, postId),
      eq(schema.postLikes.userId, userId),
      eq(schema.postLikes.userType, userType)
    ));
  await decrementPostLikes(postId);
}
