import { eq, and } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./connection";

export async function findProfile(userId: number, userType: "oauth" | "local" = "oauth") {
  const rows = await getDb()
    .select()
    .from(schema.profiles)
    .where(and(
      eq(schema.profiles.userId, userId),
      eq(schema.profiles.userType, userType)
    ))
    .limit(1);
  return rows.at(0);
}

export async function upsertProfile(data: schema.InsertProfile) {
  const existing = await findProfile(data.userId, data.userType || "oauth");
  if (existing) {
    await getDb()
      .update(schema.profiles)
      .set(data)
      .where(eq(schema.profiles.id, existing.id));
    return { ...existing, ...data };
  } else {
    await getDb().insert(schema.profiles).values(data);
    return findProfile(data.userId, data.userType || "oauth");
  }
}

export async function updateFollowerCounts(userId: number, userType: "oauth" | "local") {
  const followers = await getDb()
    .select()
    .from(schema.connections)
    .where(and(
      eq(schema.connections.followingId, userId),
      eq(schema.connections.followingType, userType)
    ));
  
  const following = await getDb()
    .select()
    .from(schema.connections)
    .where(and(
      eq(schema.connections.followerId, userId),
      eq(schema.connections.followerType, userType)
    ));

  const profile = await findProfile(userId, userType);
  if (profile) {
    await getDb()
      .update(schema.profiles)
      .set({
        followersCount: followers.length,
        followingCount: following.length,
      })
      .where(eq(schema.profiles.id, profile.id));
  }
}
