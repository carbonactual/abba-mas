import { eq, and } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./connection";

export async function createConnection(data: schema.InsertConnection) {
  const existing = await findConnection(
    data.followerId, data.followerType || "oauth",
    data.followingId, data.followingType || "oauth"
  );
  if (existing) return existing;
  
  await getDb().insert(schema.connections).values(data);
  return findConnection(
    data.followerId, data.followerType || "oauth",
    data.followingId, data.followingType || "oauth"
  );
}

export async function findConnection(
  followerId: number, followerType: "oauth" | "local",
  followingId: number, followingType: "oauth" | "local"
) {
  const rows = await getDb()
    .select()
    .from(schema.connections)
    .where(and(
      eq(schema.connections.followerId, followerId),
      eq(schema.connections.followerType, followerType),
      eq(schema.connections.followingId, followingId),
      eq(schema.connections.followingType, followingType)
    ))
    .limit(1);
  return rows.at(0);
}

export async function deleteConnection(
  followerId: number, followerType: "oauth" | "local",
  followingId: number, followingType: "oauth" | "local"
) {
  await getDb()
    .delete(schema.connections)
    .where(and(
      eq(schema.connections.followerId, followerId),
      eq(schema.connections.followerType, followerType),
      eq(schema.connections.followingId, followingId),
      eq(schema.connections.followingType, followingType)
    ));
}

export async function listFollowers(userId: number, userType: "oauth" | "local" = "oauth") {
  return getDb()
    .select()
    .from(schema.connections)
    .where(and(
      eq(schema.connections.followingId, userId),
      eq(schema.connections.followingType, userType)
    ))
    .orderBy(schema.connections.createdAt);
}

export async function listFollowing(userId: number, userType: "oauth" | "local" = "oauth") {
  return getDb()
    .select()
    .from(schema.connections)
    .where(and(
      eq(schema.connections.followerId, userId),
      eq(schema.connections.followerType, userType)
    ))
    .orderBy(schema.connections.createdAt);
}

export async function isFollowing(
  followerId: number, followerType: "oauth" | "local",
  followingId: number, followingType: "oauth" | "local"
) {
  const conn = await findConnection(followerId, followerType, followingId, followingType);
  return !!conn;
}
