import { authRouter } from "./auth-router";
import { localAuthRouter } from "./local-auth-router";
import { profileRouter } from "./profile-router";
import { feedRouter } from "./feed-router";
import { connectionRouter } from "./connection-router";
import { messageRouter } from "./message-router";
import { notificationRouter } from "./notification-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  localAuth: localAuthRouter,
  profile: profileRouter,
  feed: feedRouter,
  connection: connectionRouter,
  message: messageRouter,
  notification: notificationRouter,
});

export type AppRouter = typeof appRouter;
