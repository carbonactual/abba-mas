import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import { authenticateRequest } from "./kimi/auth";
import { findLocalUserById } from "./queries/localAuth";
import * as cookie from "cookie";
import { Session } from "@contracts/constants";
import { verifySessionToken } from "./kimi/session";

export type UnifiedUser = {
  id: number;
  name: string | null;
  email: string | null;
  avatar: string | null;
  role: "user" | "admin";
  unionId: string;
  createdAt: Date;
  updatedAt: Date;
  lastSignInAt?: Date;
};

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  user?: UnifiedUser;
};

export async function createContext(
  opts: FetchCreateContextFnOptions,
): Promise<TrpcContext> {
  const ctx: TrpcContext = { req: opts.req, resHeaders: opts.resHeaders };

  try {
    const oauthUser = await authenticateRequest(opts.req.headers);
    if (oauthUser) {
      ctx.user = {
        id: oauthUser.id,
        name: oauthUser.name,
        email: oauthUser.email,
        avatar: oauthUser.avatar,
        role: oauthUser.role as "user" | "admin",
        unionId: oauthUser.unionId,
        createdAt: oauthUser.createdAt,
        updatedAt: oauthUser.updatedAt,
        lastSignInAt: oauthUser.lastSignInAt,
      };
      return ctx;
    }
  } catch {
    // OAuth auth failed, try local auth
  }

  try {
    const cookies = cookie.parse(opts.req.headers.get("cookie") || "");
    const token = cookies[Session.cookieName];
    if (!token) return ctx;

    const claim = await verifySessionToken(token);
    if (!claim || !claim.unionId.startsWith("local_")) return ctx;

    const userId = parseInt(claim.unionId.replace("local_", ""));
    const localUser = await findLocalUserById(userId);
    if (!localUser) return ctx;

    ctx.user = {
      id: localUser.id,
      name: localUser.displayName || localUser.username,
      email: localUser.email,
      avatar: localUser.avatar,
      role: localUser.role as "user" | "admin",
      unionId: claim.unionId,
      createdAt: localUser.createdAt,
      updatedAt: localUser.updatedAt,
    };
  } catch {
    // Local auth failed
  }

  return ctx;
}
