import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import {
  listNotifications,
  markNotificationsAsRead,
  getUnreadNotificationCount,
} from "./queries/notifications";

export const notificationRouter = createRouter({
  list: authedQuery
    .input(
      z.object({
        limit: z.number().min(1).max(100).default(50),
      }).optional()
    )
    .query(async ({ ctx, input }) => {
      const user = ctx.user;
      const userType = user.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;
      const userId = userType === "local" ? parseInt(user.unionId.replace("local_", "")) : user.id;

      return listNotifications(userId, userType, input?.limit || 50);
    }),

  markRead: authedQuery.mutation(async ({ ctx }) => {
    const user = ctx.user;
    const userType = user.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;
      const userId = userType === "local" ? parseInt(user.unionId.replace("local_", "")) : user.id;

    await markNotificationsAsRead(userId, userType);
    return { success: true };
  }),

  unreadCount: authedQuery.query(async ({ ctx }) => {
    const user = ctx.user;
    const userType = user.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;
      const userId = userType === "local" ? parseInt(user.unionId.replace("local_", "")) : user.id;

    return getUnreadNotificationCount(userId, userType);
  }),
});
