import { z } from "zod";
import { createRouter, authedQuery, publicQuery } from "./middleware";
import { findProfile, upsertProfile } from "./queries/profiles";
import { findLocalUserById } from "./queries/localAuth";
import { findUserByUnionId } from "./queries/users";

type ProfileUser = {
  id: number;
  name: string | null;
  username: string | null;
  email: string | null;
  avatar: string | null;
  role: string;
  createdAt: Date;
};

async function getProfileUser(userId: number, userType: "oauth" | "local"): Promise<ProfileUser | null> {
  if (userType === "oauth") {
    const user = await findUserByUnionId(`${userId}`);
    if (!user) return null;
    return {
      id: user.id,
      name: user.name,
      username: null,
      email: user.email,
      avatar: user.avatar,
      role: user.role,
      createdAt: user.createdAt,
    };
  } else {
    const user = await findLocalUserById(userId);
    if (!user) return null;
    return {
      id: user.id,
      name: user.displayName || user.username,
      username: user.username,
      email: user.email,
      avatar: user.avatar,
      role: user.role,
      createdAt: user.createdAt,
    };
  }
}

export const profileRouter = createRouter({
  get: publicQuery
    .input(
      z.object({
        userId: z.number(),
        userType: z.enum(["oauth", "local"]).default("oauth"),
      })
    )
    .query(async ({ input }) => {
      const profile = await findProfile(input.userId, input.userType);
      const user = await getProfileUser(input.userId, input.userType);
      return { profile, user };
    }),

  update: authedQuery
    .input(
      z.object({
        bio: z.string().optional(),
        location: z.string().optional(),
        website: z.string().optional(),
        interests: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const user = ctx.user;
      const userType = user.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;
      const actualUserId = userType === "local" ? parseInt(user.unionId.replace("local_", "")) : user.id;

      const profile = await upsertProfile({
        userId: actualUserId,
        userType,
        bio: input.bio,
        location: input.location,
        website: input.website,
        interests: input.interests,
      });

      return profile;
    }),

  me: authedQuery.query(async ({ ctx }) => {
    const user = ctx.user;
    const userType = user.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;
    const userId = userType === "local" ? parseInt(user.unionId.replace("local_", "")) : user.id;
    
    const profile = await findProfile(userId, userType);
    const profileUser = await getProfileUser(userId, userType);
    return { profile, user: profileUser };
  }),
});
