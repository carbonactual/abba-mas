import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import {
  createMessage,
  listMessagesBetweenUsers,
  listConversations,
  markMessagesAsRead,
  getUnreadCount,
} from "./queries/messages";
import { createNotification } from "./queries/notifications";

export const messageRouter = createRouter({
  send: authedQuery
    .input(
      z.object({
        receiverId: z.number(),
        receiverType: z.enum(["oauth", "local"]).default("oauth"),
        content: z.string().min(1).max(5000),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const user = ctx.user;
      const senderType = user.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;
      const senderId = senderType === "local" ? parseInt(user.unionId.replace("local_", "")) : user.id;

      await createMessage({
        senderId,
        senderType,
        receiverId: input.receiverId,
        receiverType: input.receiverType,
        content: input.content,
      });

      await createNotification({
        userId: input.receiverId,
        userType: input.receiverType,
        type: "message",
        actorId: senderId,
        actorType: senderType,
        actorName: user.name || "Someone",
        actorAvatar: user.avatar || undefined,
      });

      return { success: true };
    }),

  list: authedQuery
    .input(
      z.object({
        otherUserId: z.number(),
        otherUserType: z.enum(["oauth", "local"]).default("oauth"),
      })
    )
    .query(async ({ input, ctx }) => {
      const user = ctx.user;
      const userType = user.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;
      const userId = userType === "local" ? parseInt(user.unionId.replace("local_", "")) : user.id;

      const messages = await listMessagesBetweenUsers(
        userId, userType,
        input.otherUserId, input.otherUserType
      );

      await markMessagesAsRead(input.otherUserId, input.otherUserType, userId, userType);

      return messages;
    }),

  conversations: authedQuery.query(async ({ ctx }) => {
    const user = ctx.user;
    const userType = user.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;
    const userId = userType === "local" ? parseInt(user.unionId.replace("local_", "")) : user.id;

    return listConversations(userId, userType);
  }),

  unreadCount: authedQuery.query(async ({ ctx }) => {
    const user = ctx.user;
    const userType = user.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;
    const userId = userType === "local" ? parseInt(user.unionId.replace("local_", "")) : user.id;

    return getUnreadCount(userId, userType);
  }),
});
