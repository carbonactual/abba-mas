import { z } from "zod";
import { createRouter, authedQuery, publicQuery } from "./middleware";
import {
  createConnection,
  deleteConnection,
  listFollowers,
  listFollowing,
  isFollowing,
} from "./queries/connections";
import { updateFollowerCounts } from "./queries/profiles";
import { createNotification } from "./queries/notifications";

export const connectionRouter = createRouter({
  follow: authedQuery
    .input(
      z.object({
        followingId: z.number(),
        followingType: z.enum(["oauth", "local"]).default("oauth"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const user = ctx.user;
      const followerType = user.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;
      const followerId = followerType === "local" ? parseInt(user.unionId.replace("local_", "")) : user.id;

      await createConnection({
        followerId,
        followerType,
        followingId: input.followingId,
        followingType: input.followingType,
      });

      await updateFollowerCounts(input.followingId, input.followingType);
      await updateFollowerCounts(followerId, followerType);

      await createNotification({
        userId: input.followingId,
        userType: input.followingType,
        type: "follow",
        actorId: followerId,
        actorType: followerType,
        actorName: user.name || "Someone",
        actorAvatar: user.avatar || undefined,
      });

      return { success: true };
    }),

  unfollow: authedQuery
    .input(
      z.object({
        followingId: z.number(),
        followingType: z.enum(["oauth", "local"]).default("oauth"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const user = ctx.user;
      const followerType = user.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;
      const followerId = followerType === "local" ? parseInt(user.unionId.replace("local_", "")) : user.id;

      await deleteConnection(followerId, followerType, input.followingId, input.followingType);
      await updateFollowerCounts(input.followingId, input.followingType);
      await updateFollowerCounts(followerId, followerType);

      return { success: true };
    }),

  followers: publicQuery
    .input(
      z.object({
        userId: z.number(),
        userType: z.enum(["oauth", "local"]).default("oauth"),
      })
    )
    .query(async ({ input }) => {
      return listFollowers(input.userId, input.userType);
    }),

  following: publicQuery
    .input(
      z.object({
        userId: z.number(),
        userType: z.enum(["oauth", "local"]).default("oauth"),
      })
    )
    .query(async ({ input }) => {
      return listFollowing(input.userId, input.userType);
    }),

  check: publicQuery
    .input(
      z.object({
        followerId: z.number(),
        followerType: z.enum(["oauth", "local"]).default("oauth"),
        followingId: z.number(),
        followingType: z.enum(["oauth", "local"]).default("oauth"),
      })
    )
    .query(async ({ input }) => {
      return isFollowing(input.followerId, input.followerType, input.followingId, input.followingType);
    }),
});
