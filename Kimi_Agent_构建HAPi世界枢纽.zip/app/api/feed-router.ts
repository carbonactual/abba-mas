import { z } from "zod";
import { createRouter, authedQuery, publicQuery } from "./middleware";
import {
  createPost,
  listPosts,
  listPostsByUser,
  deletePost,
  likePost,
  unlikePost,
  userLikedPost,
} from "./queries/posts";
import { findProfile } from "./queries/profiles";

export const feedRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        limit: z.number().min(1).max(100).default(50),
        offset: z.number().min(0).default(0),
      }).optional()
    )
    .query(async ({ input }) => {
      const posts = await listPosts(input?.limit || 50, input?.offset || 0);
      
      const enrichedPosts = await Promise.all(
        posts.map(async (post) => {
          const profile = await findProfile(post.userId, post.userType);
          let user = null;
          if (post.userType === "oauth") {
            const { findUserByUnionId } = await import("./queries/users");
            const users = await findUserByUnionId(`${post.userId}`);
            user = users || null;
          } else {
            const { findLocalUserById } = await import("./queries/localAuth");
            user = await findLocalUserById(post.userId) || null;
          }
          return { ...post, profile, user };
        })
      );

      return enrichedPosts;
    }),

  listByUser: publicQuery
    .input(
      z.object({
        userId: z.number(),
        userType: z.enum(["oauth", "local"]).default("oauth"),
        limit: z.number().min(1).max(100).default(50),
      })
    )
    .query(async ({ input }) => {
      const posts = await listPostsByUser(input.userId, input.userType, input.limit);
      return posts;
    }),

  create: authedQuery
    .input(
      z.object({
        content: z.string().min(1).max(2000),
        image: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const user = ctx.user;
      const userType = user.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;
      const userId = userType === "local" ? parseInt(user.unionId.replace("local_", "")) : user.id;

      await createPost({
        userId,
        userType,
        content: input.content,
        image: input.image,
      });

      return { success: true };
    }),

  delete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await deletePost(input.id);
      return { success: true };
    }),

  like: authedQuery
    .input(z.object({ postId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const user = ctx.user;
      const userType = user.unionId?.startsWith("local_") ? "local" as const : "oauth" as const;
      const userId = userType === "local" ? parseInt(user.unionId.replace("local_", "")) : user.id;

      const liked = await userLikedPost(input.postId, userId, userType);
      if (liked) {
        await unlikePost(input.postId, userId, userType);
        return { liked: false };
      } else {
        await likePost(input.postId, userId, userType);
        return { liked: true };
      }
    }),
});
