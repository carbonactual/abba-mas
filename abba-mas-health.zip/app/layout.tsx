import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ABBA MAS",
  description: "Carbon Actual master agent integration system"
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
