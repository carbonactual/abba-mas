export default function Home() {
  return (
    <main className="shell">
      <section className="card">
        <p className="eyebrow">Carbon Actual</p>
        <h1>ABBA MAS Control Plane</h1>
        <p>
          The first safe deployment check is live. Use <code>/api/health</code> to confirm
          environment variables exist without exposing secret values.
        </p>
        <a href="/api/health">Open health check</a>
      </section>
    </main>
  );
}
