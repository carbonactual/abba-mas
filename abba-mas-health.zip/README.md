# ABBA MAS

ABBA MAS is the Carbon Actual master agent integration system.

## Safe health check

After deployment, open:

```text
/api/health
```

Expected result:

```json
{
  "status": "ABBA MAS online",
  "environment": {
    "openai": true,
    "gemini": true,
    "supabaseUrl": true,
    "supabaseAnon": true,
    "supabaseService": true
  },
  "warning": "Secret values are not exposed."
}
```

No raw API keys or secret values are exposed by this route.
